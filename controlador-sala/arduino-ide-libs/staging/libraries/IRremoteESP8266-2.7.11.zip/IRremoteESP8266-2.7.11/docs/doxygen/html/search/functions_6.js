var searchData=
[
  ['fahrenheittocelsius_4130',['fahrenheitToCelsius',['../IRutils_8cpp.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp'],['../IRutils_8h.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp']]],
  ['fanspeedtostring_4131',['fanspeedToString',['../classIRac.html#ab8d8a1ce5de8970c07c90fb41731e2e6',1,'IRac']]],
  ['fixchecksum_4132',['fixChecksum',['../classIRPanasonicAc.html#aa40bef35000ddf6d14e286b3f2044897',1,'IRPanasonicAc']]],
  ['fixup_4133',['fixup',['../classIRGreeAC.html#a5bbdcc83f9d49e32379cd27cad0ba130',1,'IRGreeAC::fixup()'],['../classIRKelvinatorAC.html#a389af589003c39794ae5d4bd572fa485',1,'IRKelvinatorAC::fixup()']]],
  ['fujitsu_4134',['fujitsu',['../classIRac.html#a8060ea615d929e3f400e68693c22320d',1,'IRac']]]
];
