var searchData=
[
  ['voltas_5fac_5fremote_5fmodel_5ft_7435',['voltas_ac_remote_model_t',['../IRsend_8h.html#aaf962dae17f7186607a93128fc2d13e2',1,'IRsend.h']]]
];
